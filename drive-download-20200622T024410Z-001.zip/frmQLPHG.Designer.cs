﻿namespace QuanLyKhachSan
{
    partial class frmQLPHG
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpNgayNhan = new System.Windows.Forms.DateTimePicker();
            this.dtpNgayTra = new System.Windows.Forms.DateTimePicker();
            this.cboLoaiPHG = new System.Windows.Forms.ComboBox();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.flpTang2 = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.flpTang1 = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.flpTang3 = new System.Windows.Forms.FlowLayoutPanel();
            this.flpTang4 = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(15, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(268, 49);
            this.label1.TabIndex = 0;
            this.label1.Text = "Quản lý phòng";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(506, 60);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ngày Trả";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(78, 60);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ngày Nhận";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(885, 59);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 32);
            this.label4.TabIndex = 1;
            this.label4.Text = "Loại phòng";
            // 
            // dtpNgayNhan
            // 
            this.dtpNgayNhan.Location = new System.Drawing.Point(204, 60);
            this.dtpNgayNhan.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpNgayNhan.Name = "dtpNgayNhan";
            this.dtpNgayNhan.Size = new System.Drawing.Size(269, 27);
            this.dtpNgayNhan.TabIndex = 3;
            // 
            // dtpNgayTra
            // 
            this.dtpNgayTra.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.dtpNgayTra.Location = new System.Drawing.Point(598, 60);
            this.dtpNgayTra.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpNgayTra.Name = "dtpNgayTra";
            this.dtpNgayTra.Size = new System.Drawing.Size(269, 27);
            this.dtpNgayTra.TabIndex = 3;
            // 
            // cboLoaiPHG
            // 
            this.cboLoaiPHG.FormattingEnabled = true;
            this.cboLoaiPHG.Location = new System.Drawing.Point(1004, 58);
            this.cboLoaiPHG.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboLoaiPHG.Name = "cboLoaiPHG";
            this.cboLoaiPHG.Size = new System.Drawing.Size(254, 28);
            this.cboLoaiPHG.TabIndex = 4;
            // 
            // btnDangKy
            // 
            this.btnDangKy.Location = new System.Drawing.Point(81, 100);
            this.btnDangKy.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(202, 75);
            this.btnDangKy.TabIndex = 5;
            this.btnDangKy.Text = "Đăng ký";
            this.btnDangKy.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(9, 208);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(1260, 718);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chọn phòng";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.flpTang4);
            this.groupBox2.Location = new System.Drawing.Point(16, 26);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(1232, 76);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tầng 4";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.flpTang2);
            this.groupBox3.Location = new System.Drawing.Point(18, 194);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(1232, 78);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tầng 2";
            // 
            // flpTang2
            // 
            this.flpTang2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flpTang2.Location = new System.Drawing.Point(4, 24);
            this.flpTang2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.flpTang2.Name = "flpTang2";
            this.flpTang2.Size = new System.Drawing.Size(1224, 50);
            this.flpTang2.TabIndex = 2;
            this.flpTang2.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.flpTang1);
            this.groupBox4.Location = new System.Drawing.Point(18, 279);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Size = new System.Drawing.Size(1232, 76);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tầng 1";
            // 
            // flpTang1
            // 
            this.flpTang1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flpTang1.Location = new System.Drawing.Point(4, 24);
            this.flpTang1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.flpTang1.Name = "flpTang1";
            this.flpTang1.Size = new System.Drawing.Size(1224, 48);
            this.flpTang1.TabIndex = 2;
            this.flpTang1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.flpTang3);
            this.groupBox5.Location = new System.Drawing.Point(18, 110);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Size = new System.Drawing.Size(1232, 76);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Tầng 3";
            // 
            // flpTang3
            // 
            this.flpTang3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flpTang3.Location = new System.Drawing.Point(4, 24);
            this.flpTang3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.flpTang3.Name = "flpTang3";
            this.flpTang3.Size = new System.Drawing.Size(1224, 48);
            this.flpTang3.TabIndex = 2;
            this.flpTang3.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // flpTang4
            // 
            this.flpTang4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flpTang4.Location = new System.Drawing.Point(4, 24);
            this.flpTang4.Margin = new System.Windows.Forms.Padding(4);
            this.flpTang4.Name = "flpTang4";
            this.flpTang4.Size = new System.Drawing.Size(1224, 48);
            this.flpTang4.TabIndex = 2;
            this.flpTang4.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // frmQLPHG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1288, 651);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnDangKy);
            this.Controls.Add(this.cboLoaiPHG);
            this.Controls.Add(this.dtpNgayTra);
            this.Controls.Add(this.dtpNgayNhan);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmQLPHG";
            this.Text = "frmQLPHG";
            this.Load += new System.EventHandler(this.frmQLPHG_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpNgayNhan;
        private System.Windows.Forms.DateTimePicker dtpNgayTra;
        private System.Windows.Forms.ComboBox cboLoaiPHG;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.FlowLayoutPanel flpTang1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.FlowLayoutPanel flpTang3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.FlowLayoutPanel flpTang2;
        private System.Windows.Forms.FlowLayoutPanel flpTang4;
    }
}