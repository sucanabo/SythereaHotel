﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyKhachSan
{
    public partial class frmQLPHG : Form
    {
        public frmQLPHG()
        {
            InitializeComponent();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frmQLPHG_Load(object sender, EventArgs e)
        {
            for (int i = 1; i < 3; i++)
            {
                Button btn = new Button();
                btn.Text = "40" + i.ToString();
                //btn.(164, 41);
                flpTang4.Controls.Add(btn);

            }
            for (int i = 1; i < 4; i++)
            {
                Button btn = new Button();
                btn.Text = "40" + i.ToString();
                //btn.(164, 41);
                flpTang3.Controls.Add(btn);

            }
            for (int i = 1; i < 5; i++)
            {
                Button btn = new Button();
                btn.Text = "40" + i.ToString();
                //btn.(164, 41);
                flpTang2.Controls.Add(btn);

            }
            for (int i = 1; i < 6; i++)
            {
                Button btn = new Button();
                btn.Text = "40" + i.ToString();
                //btn.(164, 41);
                flpTang1.Controls.Add(btn);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        
    }
    
}
